<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Documentation extends Model 
{

    protected $table = 'documentations';
    public $timestamps = true;

    public function images()
    {
        return $this->hasMany('App\Image', 'document_id');
    }

    public function videos()
    {
        return $this->hasMany('App\Video', 'document_id');
    }

}