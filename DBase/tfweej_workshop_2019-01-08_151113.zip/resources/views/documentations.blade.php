{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('brife', 'Brife:') !!}
			{!! Form::textarea('brife') !!}
		</li>
		<li>
			{!! Form::label('name_country', 'Name_country:') !!}
			{!! Form::text('name_country') !!}
		</li>
		<li>
			{!! Form::label('flag', 'Flag:') !!}
			{!! Form::text('flag') !!}
		</li>
		<li>
			{!! Form::label('description', 'Description:') !!}
			{!! Form::textarea('description') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}