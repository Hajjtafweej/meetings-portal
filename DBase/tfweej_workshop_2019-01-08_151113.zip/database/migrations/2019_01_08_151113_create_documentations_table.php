<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateDocumentationsTable extends Migration {

	public function up()
	{
		Schema::create('documentations', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->text('brife')->nullable();
			$table->string('name_country')->nullable();
			$table->string('flag')->nullable();
			$table->text('description')->nullable();
		});
	}

	public function down()
	{
		Schema::drop('documentations');
	}
}